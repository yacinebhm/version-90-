<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style1.css">
    <title>Login</title>
</head>

<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "limos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Vérifier si le formulaire de login a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $email = $_POST["mail"];
    $password = $_POST["pass"];

    // Requête SQL pour vérifier les informations de l'admin
    $sql = "SELECT * FROM admin WHERE mail='$email' AND pass='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // L'admin existe dans la base de données, authentification réussie
        // Redirection vers la page index.php
        header("Location: index.php");
        exit(); // Assure que le script s'arrête après la redirection
    } else {
        // L'admin n'existe pas dans la base de données ou les informations sont incorrectes
        echo '<script type="text/javascript">';
        echo 'alert("Invalid email or password!");';
        echo 'window.location.href = "login.php";'; // Notez le point-virgule à la fin
        echo '</script>';
    }
}

// Fermer la connexion à la base de données
$conn->close();
?>





<body>

   
      
 <div class="container">
<form  method="post">
       <div class="box">
        <div class="header">
            <header><img src="assets\images\limos.jpg" alt=""></header>
            <p>Log In to LIMOSE admin</p>
        </div>
        <div class="input-box">
            <label for="mail">E-Mail</label>
            <input type="email"  name="mail" >
            <i class="bx bx-envelope"></i>
        </div>
        <div class="input-box">
            <label for="pass">Password</label>
            <input type="password" name="pass" >
            <i class="bx bx-lock"></i>
        </div>
        <div class="input-box">
            <input type="submit" name="input-submit" value="log in">
        </div>
        
    

       
    </div>
</form>
</body>
</html>