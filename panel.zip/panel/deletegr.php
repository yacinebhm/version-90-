<?php
// Connexion à la base de données MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "limos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si un ID d'administrateur est passé dans la requête GET
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Utiliser une requête SQL pour supprimer l'administrateur
    $sql = "DELETE FROM equipe WHERE id = " . $_GET['id'];

    if ($conn->query($sql) === TRUE) {
        
        echo"<script>alert('Equipe supprimé avec succès.'); window.location.href = 'group.php'; </script>";
        
    } else {
        echo "Erreur lors de la suppression de l'equipe: " . $conn->error;
    }
} else {
    echo "ID de l'equipe non spécifié.";
    
}

// Fermer la connexion à la base de données
$conn->close();
?>
