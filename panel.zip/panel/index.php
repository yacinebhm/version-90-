<?php
// Events
function connexion_bd() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_equipes() {
    $conn = connexion_bd();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_equipes FROM evenement";
    $result = $conn->query($sql);

    $nombre_equipes = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_equipes = $row["nombre_equipes"];
    }

    $conn->close();

    return $nombre_equipes;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_equipes = recuperer_nombre_equipes();
?>




<?php
// teams
function connexionbd() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_teams() {
    $conn = connexionbd();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_teams FROM equipe";
    $result = $conn->query($sql);

    $nombre_teams = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_teams = $row["nombre_teams"];
    }

    $conn->close();

    return $nombre_teams;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_teams = recuperer_nombre_teams();
?>


<?php
// members
function connexionl() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_mem() {
    $conn = connexionbd();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_mem FROM membre";
    $result = $conn->query($sql);

    $nombre_mem = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_mem = $row["nombre_mem"];
    }

    $conn->close();

    return $nombre_mem;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_mem = recuperer_nombre_mem();
?>


<?php
// admins
function connexiona() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_ad() {
    $conn = connexiona();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_ad FROM admin";
    $result = $conn->query($sql);

    $nombre_admin = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_admin = $row["nombre_ad"];
    }

    $conn->close();

    return $nombre_admin;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_admin = recuperer_nombre_ad();
?>



<?php
// university
function connexionu() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_u() {
    $conn = connexiona();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_un FROM universites";
    $result = $conn->query($sql);

    $nombre_uni = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_uni = $row["nombre_un"];
    }

    $conn->close();

    return $nombre_uni;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_uni = recuperer_nombre_u();
?>



<?php
// join event
function connexionj() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_je() {
    $conn = connexionj();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_je FROM demande_participation_event";
    $result = $conn->query($sql);

    $nombre_je = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_je = $row["nombre_je"];
    }

    $conn->close();

    return $nombre_je;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_je = recuperer_nombre_je();
?>



<?php
// join team
function connexionjt() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_jt() {
    $conn = connexionjt();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_jt FROM demande_participation_equipe";
    $result = $conn->query($sql);

    $nombre_jt = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_jt = $row["nombre_jt"];
    }

    $conn->close();

    return $nombre_jt;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_jt = recuperer_nombre_jt();
?>



<?php
// contact
function connexionc() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Fonction pour récupérer le nombre d'équipes
function recuperer_nombre_c() {
    $conn = connexionc();

    $sql = "SELECT COUNT(DISTINCT id) AS nombre_c FROM contact";
    $result = $conn->query($sql);

    $nombre_c = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre_c = $row["nombre_c"];
    }

    $conn->close();

    return $nombre_c;
}

// Appeler la fonction pour récupérer le nombre d'équipes
$nombre_c = recuperer_nombre_c();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Home </title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <img src="assets/imgs/limose1.png" alt="Small Image">
                        </span>
                        <span class="title">Limose Laboratory</span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="member.php">
                        <span class="icon">
                            <ion-icon name="person-add-outline"></ion-icon>

                        </span>
                        <span class="title">Members</span>
                    </a>
                </li>

                <li>
                    <a href="event.php">
                        <span class="icon">
                            <ion-icon name="golf-outline"></ion-icon>
                        </span>
                        <span class="title">Events</span>
                    </a>
                </li>

                <li>
                    <a href="group.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Teams</span>
                    </a>
                </li>

                <li>
                    <a href="admin.php">
                        <span class="icon">
                            <ion-icon name="person-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Admins</span>
                    </a>
                </li>

                <li>
                    <a href="uni.php">
                        <span class="icon">
                            <ion-icon name="school-outline"></ion-icon>
                        </span>
                        <span class="title">University</span>
                    </a>
                </li>

                <li>
                    <a href="demande_event.php">
                        <span class="icon">
                            <ion-icon name="calendar-outline"></ion-icon>
                        </span>
                        <span class="title">Request join Event</span>
                    </a>
                </li>
                
                <li>
                    <a href="demande_team.php">
                        <span class="icon">
                            <ion-icon name="add-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Request join Team</span>
                    </a>
                </li>

                <li>
                    <a href="contact-us.php">
                        <span class="icon">
                            <ion-icon name="file-tray-full-outline"></ion-icon>
                        </span>
                        <span class="title">Contact-us</span>
                    </a>
                </li>

                <li>
                    <a href="signout.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="assets/imgs/customer01.jpg" alt="">
                </div>
            </div>


            

            <!-- ======================= Cards ================== -->
            <div class="cardBox">
                <div class="card">
                    <div>
                        <div class="numbers">1,504</div>
                        <div class="cardName">Daily Views</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="eye-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <a href="event.php">
                        <div>
                            <div class="numbers">
                                <?php echo $nombre_equipes; ?>
                            </div>
                            <div class="cardName">Events</div>
                        </div>
                    </a>
                    <a href="event.php">
                        <div class="iconBx">
                            <ion-icon name="golf-outline"></ion-icon>
                        </div>
                    </a>
                </div>

                <div class="card">
                    <a href="group.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_teams; ?>
                        </div>
                        <div class="cardName">Teams</div>
                    </div>
                    </a>
                    <a href="group.php">
                    <div class="iconBx">
                        <ion-icon name="people-outline"></ion-icon>
                    </div>
                    </a>
                </div>

                <div class="card">
                    <a href="member.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_mem; ?>
                        </div>
                        <div class="cardName">Members</div>
                    </div>
                    </a>
                    <a href="member.php">
                    <div class="iconBx">
                        <ion-icon name="person-add-outline"></ion-icon>
                    </div>
                    </a>
                </div>


                <div class="card">
                    <a href="admin.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_admin; ?>
                        </div>
                        <div class="cardName">Admins</div>
                    </div>
                    </a>
                    <a href="admin.php">
                    <div class="iconBx">
                       <ion-icon name="person-circle-outline"></ion-icon>
                    </div>
                    </a>
                </div>
                <div class="card">
                    <a href="uni.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_uni; ?>
                        </div>
                        <div class="cardName">University</div>
                    </div>
                    </a>
                    <a href="uni.php">
                    <div class="iconBx">
                      <ion-icon name="school-outline"></ion-icon>
                    </div>
                    </a>
                </div>

                <div class="card">
                    <a href="demande_event.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_je; ?>
                        </div>
                        <div class="cardName">Request join Event</div>
                    </div>
                    </a>
                    <a href="demande_event.php">

                    <div class="iconBx">
                       <ion-icon name="calendar-outline"></ion-icon>
                    </div>
                    </a>
                </div>

                <div class="card">
                    <a href="demande_team.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_jt; ?>
                        </div>
                        <div class="cardName">Request join Team</div>
                    </div>
                    </a>
                    <a href="demande_team.php">

                    <div class="iconBx">
                       <ion-icon name="add-circle-outline"></ion-icon>
                    </div>
                    </a>
                </div>
                <div class="card">
                    <a href="contact-us.php">
                    <div>
                        <div class="numbers">
                        <?php echo $nombre_c; ?>
                        </div>
                        <div class="cardName">Contact-us</div>
                    </div>
                    </a>
                    <a href="contact-us.php">

                    <div class="iconBx">
                      <ion-icon name="file-tray-full-outline"></ion-icon>
                    </div>
                    </a>
                </div>
            </div>


        </div>
    </div>
    </div>

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>



